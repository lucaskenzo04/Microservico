package com.github.lucaskenzo04.ms_pagamento;

import org.springframework.data.jpa.repository.JpaRepository;
import com.github.lucaskenzo04.ms_pagamento.model.Pagamento;


public interface PagamentoRepository extends JpaRepository<Pagamento, Long> {

}
