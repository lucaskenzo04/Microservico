package com.github.lucaskenzo04.ms_pagamento;
import com.github.lucaskenzo04.ms_pagamento.model.Status;
import lombok.Getter;

@Getter
public class StatusDTO {

    private Status status;

}
