package com.github.lucaskenzo04.ms_pagamento.model;

public enum Status {
    CRIADO,
    CONFIRMADO,
    CANCELADO
}
