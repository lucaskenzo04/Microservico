package com.github.lucaskenzo04.ms_pagamento;

import com.github.lucaskenzo04.ms_pagamento.PagamentoDTO;
import com.github.lucaskenzo04.ms_pagamento.PagamentoRepository;
import com.github.lucaskenzo04.ms_pagamento.model.Pagamento;
import com.github.lucaskenzo04.ms_pagamento.model.Status;
import jakarta.persistence.Entity;
import jakarta.persistence.EntityNotFoundException;
import org.hibernate.proxy.EntityNotFoundDelegate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.GetMapping;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class PagamentoService {

    @Autowired
    private PagamentoRepository repository;

   @Transactional(readOnly = true)
    public List<PagamentoDTO> findAll(){
        List<Pagamento> List = repository.findAll();
        return List.stream().map(PagamentoDTO::new).collect(Collectors.toList());
    }

    @Transactional(readOnly = true)
    public PagamentoDTO findById(long id) {
       Pagamento entity = repository.findById((id).orElseThrow(
               ()-> new EntityNotFoundException("Recurso nao encontrado")

       );
       return new PagamentoDTO(entity);
    }
}
@Transactional
public PagamentoDTO insert(PagamentoDTO dto){
    Pagamento entity = new Pagamento();
    copyDtoEntity(dto, entity);
    entity = repository.save(entity);
    return new PagamentoDTO(entity);

}
 private void copyDtoEntity(PagamentoDTO dto, Pagamento entity){
    entity.setValor(dto.getValor());
    entity.setNome(dto.getValidade());
    entity.setNumeroDoCartao(dto.getNumeroDoCartao());
    entity.setValidade(dto.getValidade());
    entity.setCodigoDeSeguranca(dto.getCodigoDeSeguranca());
    entity.setStatus(Status.CRIADO);
    entity.setPedidoId(dto.getPedidoId());
    entity.setFormaDePagamentoId(dto.getFormaDePagamentoId());

 }
 }



